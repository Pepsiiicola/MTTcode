
% 设置窗布大下
% 前两个参数表示在显示器中的起始坐标，后两个表示图像窗口的长和�?
% set(gcf,'Position',[100 100 500 300]);%2
% set(gcf,'Position',[100 100 280 200]);%3
set(gcf,'Position',[100 100 800 350]);%2
%设置字体大小
set(gca,'Fontsize',14)%2
% set(gca,'Fontsize',12)%3
% set(gca,'Fontsize',11.5)%3
%
box on;
%网格
grid on;